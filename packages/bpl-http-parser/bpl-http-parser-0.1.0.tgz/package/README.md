# bpl-http-parser

`HttpParser.parse(raw)` parses a NUL-terminated request. Use
`HttpParser.parseBytes(raw, byteCount)` for bounded buffers and binary bodies.

Check `valid` before using fields. When false, `error_code == 0` means more
bytes are needed; nonzero values are HTTP rejection statuses. Header lookup is case-insensitive. Query keys and values decode percent escapes and `+`; repeated
keys keep the last value, and a bare key has an empty value.

The parser requires an origin-form target and HTTP/1.0 or HTTP/1.1. HTTP/1.1
requires one nonempty Host header. The request line must end with CRLF; a CR
followed by any other byte is rejected. Headers are limited to 16 KiB and bodies
to 1 MiB. Duplicate Content-Length, Cookie, Origin, Authorization, or X-CSRF-Token
headers, invalid lengths, malformed headers, and
invalid query escapes are rejected. HTTP/1.1 chunked requests are decoded, including bounded chunk extensions and
validated trailers. Other transfer codings return 501. Content-Length together
with Transfer-Encoding is rejected. `message_length` marks the first
request boundary; extra bytes are not incorporated into the body.

All returned strings and header collections/maps belong to the result. Call `destroy()` on
success, failure, or incomplete input. Copying the result does not copy its
allocations; destroy the owner once. Borrowed fields expire at destruction.

`HttpHeaders` is shared by parsed requests, server requests/responses and the HTTP
client. `set(name,value)` replaces all lines; `append(name,value)` preserves a
new line; `getAll(name)` returns an owning array of borrowed strings (destroy
that array, not its values). `get(name)` combines repeated values with commas,
except Cookie uses semicolons and Set-Cookie returns the first line: use getAll
for every cookie. `remove(name)` removes all matching lines. Names/values are
copied, validated and owned until destroy; original wire name casing is retained.
Do not copy the owning collection. Raw Map operations on headers are replaced by
these methods. Parsed Content-Type, Expect and Access-Control-Request-Method
also reject duplicates rather than joining ambiguous singleton values.

Decoded chunked bodies are limited to 1 MiB, chunk metadata to 64 KiB, each chunk
size/extension line to 1 KiB, and trailers to 16 KiB. `trailers` is a separate
HttpHeaders collection: trailer fields never initialize ordinary headers.
Framing, routing, authentication and representation metadata are forbidden in
trailers. `ChunkDecoder.parse(data,size)` exposes the same incremental decoder;
check valid/error_code, and destroy the owning result even for incomplete input.

Header names remain ASCII tokens; values preserve opaque bytes including UTF-8
and other high octets, while rejecting C0 controls (except horizontal tab) and
DEL. Per-field encodings such as extended filename parameters remain the
application's responsibility. Authentication, cache/control and range/conditional
fields cannot be introduced by trailers.
